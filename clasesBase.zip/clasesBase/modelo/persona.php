<?php 
class Persona {
    // Atributos privados (encapsulamiento)
    private $nombres;
    private $apellidos;
    private $edad;
    private $genero;

public function __construct($nombres, $apellidos, $edad, $genero)
{
     $this->registrarPersona($nombres, $apellidos, $edad, $genero);
}

public function registrarPersona($nombres,$apellidos,$edad,$genero){
    $this->nombres = $nombres;
    $this->apellidos = $apellidos;
    $this->edad = $edad;
    $this->genero = $genero;
}
public function saludar()
{
return "hola, soy ". $this->nombres . " ". $this->apellidos ." Como estas? ";
}

public function mostrarEtiquetaInformativa() {
    $genero = ($this->genero == 'M') ? 'Masculino' : 'Femenino';
    return "Nombre: ". $this->nombres. " ". $this->apellidos. " , Edad: ". $this->edad. "años, Género: ".  $genero;
}

public function esMayorDeEdad() {
    return $this->edad >= 18;
}



// metodos clasicos en clases los getters, para obtener informacion puntual de forma segura
    public function getNombres() {
        return $this->nombres;
    }

    public function getApellidos() {
        return $this->apellidos;
    }

    public function getEdad() {
        return $this->edad;
    }

    public function getGenero() {
        return $this->genero;
    }
// metodos clasicos en clases los setters, para configurar informacion puntual de forma segura
    public function setNombres($nombres) {
        $this->nombres = $nombres;
    }

    public function setApellidos($apellidos) {
        $this->apellidos = $apellidos;
    }

    public function setEdad($edad) {
        $this->edad = $edad;
    }

    public function setGenero($genero) {
        $this->genero = $genero;
    }



   public function actualizar($datos) {
        if (isset($datos['nombres'])) {
            $this->setNombres($datos['nombres']);
        }
        if (isset($datos['apellidos'])) {
            $this->setApellidos($datos['apellidos']);
        }
        if (isset($datos['edad'])) {
            $this->setEdad($datos['edad']);
        }
        if (isset($datos['genero'])) {
            $this->setGenero($datos['genero']);
        }
    }
    public function eliminar() {
        $this->nombres = null;
        $this->apellidos = null;
        $this->edad = null;
        $this->genero = null;
    }
}
?>