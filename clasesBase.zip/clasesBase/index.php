<?php 

require_once("modelo/persona.php");
$objPersona=new Persona('Juan A','Perez O',28,'M');
echo $objPersona->saludar();
echo "<br>";
echo $objPersona->mostrarEtiquetaInformativa();
echo "<br>";
echo $objPersona->esMayorDeEdad() ? "Esta persona es mayor de edad." : "Esta persona es menor de edad.";
 ?>